<template>
	<el-empty image="img/404.png" :image-size="280" description="当前账号未满足开通企业账号权限">
		<el-button type="primary" size="large" round disabled>立即升级为企业账号</el-button>
	</el-empty>
</template>

<script>
	export default {
		data() {
			return {

			}
		}
	}
</script>

<style>
</style>
