﻿## 说明文档（可选）

- [] 这是一个示例插件
- [x] 感谢使用

## API

- [/SayHello](/SayHello)
  - 通过插件在运行时添加 管道Middleware, 并拦截响应

- [/api/plugins/Hello](/api/plugins/Hello)
  - 通过插件Controller 响应

## 前端视图

- [/Plugins/HelloWorldPlugin](/Plugins/HelloWorldPlugin)

## 挂件

- [/api/plugincore/PluginWidget/Widget?widgetKey="PluginCore.Admin.Footer"&extraPars="a","b","c"](/api/plugincore/PluginWidget/Widget?widgetKey="PluginCore.Admin.Footer"&extraPars="a","b","c")
  - [/api/plugincore/PluginWidget/Widget?widgetKey=%22PluginCore.Admin.Footer%22&extraPars=%22a%22,%22b%22,%22c%22](/api/plugincore/PluginWidget/Widget?widgetKey=%22PluginCore.Admin.Footer%22&extraPars=%22a%22,%22b%22,%22c%22)